import sys
import socket
import threading
from protocol import send_json, recv_json

import time

# --- 遊戲邏輯類別 (TetrisState) ---
# 這裡包含你原本的 Board 運算、消行、碰撞偵測
class TetrisState:
    def __init__(self):
        self.width, self.height = 10, 20
        self.board = [[0]*self.width for _ in range(self.height)]
        self.score = 0
        self.is_lost = False
    
    def get_snapshot(self):
        return {"board": self.board, "score": self.score, "is_lost": self.is_lost}
    # ... 此處省略具體方塊運算，請填入你原本的 TetrisState 內容 ...

clients = []
clients_lock = threading.Lock()
game_started = False

def broadcast(msg):
    with clients_lock:
        for c in clients:
            try: send_json(c['conn'], msg)
            except: pass

def handle_player(conn, addr, room_id):
    global game_started
    user = "Unknown"
    try:
        # 第一個訊息通常是 User 資訊
        init_req = recv_json(conn)
        if init_req: user = init_req.get('user', 'Player')
        
        state = TetrisState()
        with clients_lock:
            clients.append({'conn': conn, 'user': user, 'state': state})
            count = len(clients)
        
        print(f"[遊戲] {user} 加入房間 {room_id}. 目前人數: {count}/2")
        
        # 滿 2 人自動開始
        if count >= 2 and not game_started:
            game_started = True
            broadcast({'type': 'START'})

        while True:
            msg = recv_json(conn)
            if not msg: break
            # 處理 MOVE, ROTATE 指令並更新 state...
    except: pass

def start_game_server(port, room_id):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', int(port)))
    s.listen(2)
    print(f"[遊戲伺服器] 啟動於 Port {port}")
    
    # 啟動 Tick Thread 負責發送畫面 (Snapshot)
    def tick():
        while True:
            if game_started:
                snapshots = {c['user']: c['state'].get_snapshot() for c in clients}
                broadcast({'type': 'SNAPSHOT', 'data': snapshots})
            time.sleep(0.1)
    
    threading.Thread(target=tick, daemon=True).start()

    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_player, args=(conn, addr, room_id), daemon=True).start()

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(1)
    start_game_server(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "None")

def start_game_server(port, room_id):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('0.0.0.0', int(port)))
    s.listen(2)
    print(f"[遊戲伺服器] 已啟動於 Port: {port}, 房間 ID: {room_id}")
    
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_player, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    # Server 啟動格式: python game_server.py [port] [room_id]
    if len(sys.argv) < 2:
        sys.exit(1)
    start_game_server(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "None")