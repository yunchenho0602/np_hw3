import sys
from protocol import send_json, recv_json # 使用包內自帶的協定

import socket
import threading
import tkinter as tk

class TetrisGUI:
    def __init__(self, username, ip, port):
        self.username = username
        self.root = tk.Tk()
        self.root.title(f"Tetris - {username}")
        self.canvas = tk.Canvas(self.root, width=400, height=500, bg='black')
        self.canvas.pack()
        
        # 連線至遊戲伺服器
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, int(port)))
        send_json(self.sock, {"user": username})
        
        self.root.bind("<Key>", self.handle_key)
        threading.Thread(target=self.listen_server, daemon=True).start()
        self.root.mainloop()

    def handle_key(self, event):
        # 將按鍵轉換為指令發送給 game_server
        mapping = {"Left": "left", "Right": "right", "Down": "down", "Up": "rotate"}
        if event.keysym in mapping:
            send_json(self.sock, {"type": "MOVE", "dir": mapping[event.keysym]})

    def listen_server(self):
        while True:
            msg = recv_json(self.sock)
            if not msg: break
            if msg['type'] == 'SNAPSHOT':
                self.draw_board(msg['data'])
            elif msg['type'] == 'GAME_OVER':
                print(f"遊戲結束！贏家: {msg['winner']}")
                break

    def draw_board(self, data):
        self.canvas.delete("all")
        # 根據收到自己的 board 和對手的 board 進行繪製...
        pass

def main():
    # 大廳啟動指令格式: python run.py [username] [server_ip] [game_port]
    if len(sys.argv) < 4:
        print("Usage: python run.py <username> <ip> <port>")
        sys.exit(1)

    username = sys.argv[1]
    server_ip = sys.argv[2]
    server_port = int(sys.argv[3])

    print(f"--- 遊戲已啟動 ---")
    print(f"玩家名稱: {username}")
    print(f"連線目標: {server_ip}:{server_port}")

    if len(sys.argv) < 4:
        print("參數錯誤")
        return
    # 接收來自大廳的參數
    user, ip, port = sys.argv[1], sys.argv[2], sys.argv[3]
    TetrisGUI(user, ip, port)

    # TODO: 開發者在此建立 GUI 並連線至遊戲伺服器
    # 例如: client_socket.connect((server_ip, server_port))

if __name__ == "__main__":
    main()